# QA_PHASE4 — Phase 4 independent QA of the installed doc sync

Owner: Fable (QA Lead). Created 2026-10-19. Candidate: branch `docs/sync-doctrine-part2-2026-10-15` @ `20f71ee9…` (CONTENT_SHA `ef35d26d…`), approved spec R1 `2a3867ca…`.

| File | Purpose |
|---|---|
| `QA_READINESS_RECORD.md` | Fable's precondition evidence (24 checks PASS) and observations R-1…R-7; readiness decision READY |
| `qa_readiness.py` → `QA_READINESS.json`, `QA_READINESS_RAW.json` | reproducible readiness checks (read-only Git) and their raw command record |
| `OVERRIDES_AND_ALIGNMENT.md` | QA Lead alignment of the frozen spec with Tony's recorded rulings (O-1…O-8); no spec bytes change |
| `AC_EXECUTION_CHECKLIST.md` | the complete QA Executor assignment, AC1…AC38 + 10X-COPY, with commands, reads and the evidence layout |
| `QA_EXECUTOR_PROMPT.md` | the ready-to-run prompt for the fresh QA Executor session (Tony launches it) |
| `EXECUTOR_EVIDENCE/` | QA Executor package (Codex, fresh session, 2026-10-19T05:41Z): 31 PASS / 8 FAIL, findings F01–F07; byte-identical to `/home/moose/Downloads/QA_PHASE4_EXECUTOR_20f71ee_2026-10-19.zip` (SHA-256 `64ec4aca…`) |
| `qa_adjudicate.py` → `ADJUDICATION_EVIDENCE.json` | Fable's independent span checks (BASE vs candidate, map dispositions) for F01–F07 |
| `QA_LEAD_VERDICT.md` | **FAIL** — F01–F05 confirmed (AC5, AC6, AC9, AC15, AC16, AC18); F06/F07 rejected → follow-ups FU-1/FU-2; 33 PASS / 6 FAIL |
| `REPAIR_QA_P4/ENGINEER_REPAIR_PROMPT.md`, `REPAIR_FINDINGS.json` | one bounded repair assignment for Cody (AMENDED-v2, six documents, content-only) with acceptance criteria R1–R12 and the bounded retest list |

Nothing here modifies the candidate worktree, frozen records, `main`, or any Git state.
