# RECON QUESTIONNAIRE — Ground-Truth Verification Before FFM Authoring

> **Version:** 0.6 · **Date:** 2026-10-18 · **Status:** Active (living document — grows with every FFM run's lessons)
> **Tier:** 2 — Pipeline Agents · **Pairs with:** ARCHITECT_PLAYBOOK, FFM_PLAYBOOK, APP_FACTORY_BLUEPRINT, STARTER_KIT_HANDBOOK

> **Purpose:** Catch repo-vs-doctrine drift BEFORE the Architect authors an FFM, not after the Engineer surfaces it at Discovery.
> **Owner:** Stark Industries — App Factory
> **Where this sits:** Recon is **Phase 0 of the APP_FACTORY_BLUEPRINT lifecycle** and **Stage 0 of FFM module preparation**. ARCHITECT_PLAYBOOK §2 (Recon Mode) is the law that makes it mandatory; the `stark-recon` skill automates it — **this questionnaire is the skill's source content.**

---

## Why This Exists

Every conflict that surfaced at the Cyber Pharma v1 Phase 1 Discovery gate traced to the same root cause: **the Architect authored the FFM without ground-truth access to the actual repo.** The FFM was written from operator descriptions, the starter kit handbook, and project-knowledge docs — and some of those sources were themselves wrong.

Conflicts that a recon pass would have caught up front (all from Cyber Pharma v1 Phase 1):

| Conflict | Root cause | Recon question that catches it |
|---|---|---|
| Next.js 15 vs 16 | Architect used global default, never checked `package.json` | Q1.1–1.3 (stack versions) |
| authService wrapper vs kit's complete auth | Architect trusted DATA_CONTRACT over the kit's actual implementation | Q3.1–3.4 (auth pattern) |
| `app-role.ts` ghost file | Handbook claimed a file that doesn't exist; Architect inherited the lie | Q2.1–2.3 (kit structure vs handbook claims) |
| `src/services/` exists unexpectedly | No one checked what the kit already ships | Q2.4 (existing directories) |
| Demo "posts" scaffolding cascade (11 files) | No one checked what tutorial filler the kit ships | Q8.1–8.3 (demo/tutorial scaffolding) — NEW in v0.2 |
| `useAuthStore` missing derived flags (`isAdmin` etc.) | Handbook claimed flags that don't exist on disk | Q3.6 (store shape) — NEW in v0.2 |
| `useAuthStore.user` typed `any` | Latent forbidden-zone violation in the kit since init | Q3.7 (type-safety smells) — NEW in v0.2 |
| FFM templates break `tsc --noEmit` | FFM's `.ts` template stubs caught in compile scope | Q9.1 (tsconfig scope) — NEW in v0.2 |
| Skills resolve from wrong CWD | Skills load relative to launch dir, not repo root | Q6.5 (launch CWD) — already in v0.1, elevated |

**The pattern:** none of these were deep design failures. They were all "the Architect couldn't see the ground truth." The fix is cheap: have the Engineer (Claudy, who IS in the repo) answer a questionnaire before the Architect writes a line.

**The meta-lesson (the biggest one):** the **starter kit handbook is aspirational, not literal.** By the end of Phase 1, FOUR separate handbook claims were proven false against on-disk reality (the `app-role.ts` location, the "files already separated" split, the `useAuthStore` derived flags, and the `user` type). Treat the handbook as a description of *intent*, and verify every load-bearing claim against the filesystem during recon. **Disk establishes implementation facts; report drift without changing approved scope or requirements.**

---

## How To Use This

### The Recon Pass (Stage 0 of FFM authoring)

```
1. Architect (Claude in chat) hands the operator this questionnaire,
   tuned for the specific project/phase being authored.

2. Operator (you) runs Claudy in the repo:
   "Answer the RECON QUESTIONNAIRE from ground truth. Read-only —
    read-only filesystem and Git inspection plus declared reporting writes.
    No Git mutations. Diagnostic changes require explicit authorization.
    Report findings verbatim."

3. Claudy answers from the filesystem — actual versions, actual file
   locations, actual kit contents, actual grep results.

4. Architect authors the FFM from VERIFIED FACTS.
   No more "the handbook claims..." — now it's "confirmed on disk..."
```

### Discipline

- **Inspection and declared reporting.** Read-only filesystem/Git inspection and declared recon/reporting writes are allowed. Git mutations belong to the Director. Build, cache or other diagnostic changes require explicit authorization naming expected writes; otherwise report the limitation.
- **Verbatim findings.** Claudy reports what it actually found, including when reality contradicts the handbook. Doc-vs-reality drift is the single highest-value finding.
- **One pass.** The questionnaire is answered in one shot and handed back. The Architect then authors. Don't trickle questions one at a time.

---

## SECTION 0 — The Day-1 Ground-Truth Sweep (Run 001 Meta-Lesson)

Record the actual server-only Supabase credential variable name used by this project and its approved alias mapping. Reference examples using SUPABASE_SERVICE_ROLE_KEY or SUPABASE_SECRET_KEY are alternative project profiles, not two automatically configured credentials. Confirm each consumer against the same contract; never expose either credential in client bundles or logs.

> **THE governing lesson from Cyber Pharma v1 Phase 1:** *handbook implementation claims require recon; the approved APP_BRIEF remains the scope contract.* Six confirmed handbook bugs in one run. Every doc claim about disk state that went unverified became a shipped wrong assumption. **Disk establishes implementation facts; approved briefs govern scope and governing documents control their subjects. Route genuine conflicts to the Director.**
>
> This section is the consolidated "verify before you trust" sweep. Run it FIRST, before authoring anything. Every check here exists because trusting a doc instead of disk cost real time in Run 001.

```bash
# S0.1 — VERIFY EVERY HANDBOOK-NAMED FILE EXISTS (L1, L5)
#   The handbook claimed src/utils/app-role.ts existed. It didn't.
#   For every file the handbook names, confirm it's on disk:
#   (build the list from the handbook, then:)
for f in <each-handbook-named-file>; do ls -la "$f" 2>/dev/null || echo "MISSING (handbook lie): $f"; done

# S0.2 — VERIFY EVERY HANDBOOK-CLAIMED EXPORT/SHAPE MATCHES DISK (L5, L6)
#   Handbook claimed useAuthStore exposes isAdmin/isMember/isSuperadmin. It didn't.
#   Handbook implied user was typed. It was `any`.
#   For each store/util the handbook describes, cat the file and compare the ACTUAL
#   exported shape to the claim. Note every mismatch.

# S0.3 — FORBIDDEN-ZONE GREP AGAINST THE KIT BASELINE (L6)
#   Run the Stark forbidden-zone greps on the KIT ITSELF, day 1 — not at SP-close.
#   The kit shipped `user: any` from init. Catch kit-level violations before authoring.
grep -rn ": any\b\|as any" src/ | grep -v node_modules
grep -rn "dangerouslySetInnerHTML" src/ | grep -v node_modules
grep -rn "user_metadata\.\(is_\|role\)" src/ | grep -v node_modules

# S0.4 — VERIFY EVERY DOC-NAMED ROUTE/PATH BY find (L7)
#   APP_BRIEF said the vuln route was under api/superadmin/. It was at api/auth/.
#   For every "route X is at path Y" claim, find the ACTUAL path before scoping work:
find src/app -type d -name "<claimed-route-segment>"

# S0.5 — VERIFY THE TEST RUNNER (L8)
#   Handbook said Vitest. Kit used Jest. The flag mismatch was the only signal.
grep -E '"test":|vitest|jest' package.json

# S0.6 — GROUND-TRUTH ENV NAMES FROM .env.local.example + CODE, NOT DOCS (L9, L24)
#   APP_BRIEF specified stale Supabase names (anon/service_role). Real code used the
#   Q4-2025 naming (publishable/secret). Doc env names are SUGGESTIVE, not authoritative.
cat .env.local.example .env.example 2>/dev/null
grep -rn "process\.env\." src/ | grep -oP "process\.env\.\w+" | sort -u
#   Confirm env vars are STAGED before any build is asked to pass (L24).

# S0.7 — RUN THE BUILD ROUTE TABLE (L7, L32)
#   The route table is ground truth for "what surfaces actually exist." It surfaced
#   /demo, /template, /api/ghl/ (a year-old QR fossil), and the real vuln-route path.
# DIAGNOSTIC CHANGES: run only after explicit authorization.
# Capture command, working directory, exit code and unfiltered output.
# Without authorization, report this check as not performed; do not run it.
npm run build
```

**The rule:** when this sweep and a doc disagree, the sweep wins, and the doc gets flagged for correction (kit handbook v3). Don't author a single FFM line against an unverified doc claim. Every handbook bug in Run 001 (L1, L5, L6, L7, L8 — plus the env-name and runner drift) would have been caught here on Day 1 instead of mid-build.

---

## SECTION 1 — Stack Versions

The global doctrine pins versions that age. The repo's `package.json` is the only truth.

```bash
# Q1.1 — Next.js version
grep '"next"' package.json

# Q1.2 — React version
grep '"react"' package.json

# Q1.3 — Tailwind version (determines token mechanic: HSL/config vs @theme/OKLCH)
grep tailwindcss package.json

# Q1.4 — TypeScript version
grep '"typescript"' package.json

# Q1.5 — Node version (if pinned)
cat .nvmrc 2>/dev/null; grep '"node"' package.json 2>/dev/null

# Q1.6 — full dependency snapshot for anything the FFM will reference
cat package.json

# Q1.7 — Which test runner does the kit ACTUALLY use? (don't trust the handbook)
#         Phase 1 found: doctrine said Vitest, kit used Jest.
grep -E '"test"|vitest|jest' package.json
```

**Architect uses this to:** write exact versions into `_project/CLAUDE.md` § Tech Stack, so the Engineer never surfaces a stack conflict at Discovery. Global defaults are the fallback; the repo wins.

---

## SECTION 2 — Kit Structure vs Handbook Claims

The handbook describes what the kit *should* contain. The filesystem describes what it *actually* contains. When they disagree, record the factual drift and route any requirements conflict to the Director.

```bash
# Q2.1 — Verify every file the handbook claims exists
#         (run for each path the handbook names in its "files already separated" section)
ls -la src/utils/
ls -la src/services/ 2>/dev/null
ls -la src/store/ 2>/dev/null
ls -la src/types/

# Q2.2 — Where is a given exported symbol ACTUALLY defined?
#         (the app-role.ts lesson: handbook said one file, reality was another)
grep -rn "export.*AppRole" src/ | grep -v node_modules
grep -rn "export.*getUserRole" src/ | grep -v node_modules

# Q2.3 — Route group inventory (confirm what (groups) actually exist)
find src/app -maxdepth 1 -type d -name "(*)"

# Q2.4 — What's ALREADY in src/services/? (don't author wrappers for what exists)
ls -la src/services/ 2>/dev/null && echo "--- contents ---" && \
  for f in src/services/*; do echo "## $f"; head -20 "$f" 2>/dev/null; done

# Q2.5 — Middleware vs proxy (Next 16 ships src/proxy.ts, not middleware.ts)
ls -la src/middleware.ts src/proxy.ts 2>/dev/null
```

**Architect uses this to:** stop inheriting handbook errors. Every file path written into the FFM is one Claudy confirmed exists. Drift gets logged as a "kit reconciliation" task for the appropriate sub-phase.

---

## SECTION 3 — Auth & RBAC Pattern (The authService Trap)

The single most common conflict: DATA_CONTRACT defines a service wrapper for auth the kit already provides complete. Verify what the kit actually does BEFORE writing any service contract.

```bash
# Q3.1 — How do components currently read the authenticated user?
grep -rn "useAuthStore\|useUser\|getUser\|getCurrentUser" src/ | grep -v node_modules | head -20

# Q3.2 — How is the user's ROLE resolved?
grep -rn "getUserRole\|resolveRole\|AppRole\|user_roles" src/ | grep -v node_modules | head -20

# Q3.3 — Is there an existing auth service, or is auth consumed directly?
ls -la src/services/*auth* 2>/dev/null
grep -rn "authService\|AuthService" src/ | grep -v node_modules

# Q3.4 — SECURITY: any roles read from user_metadata? (forbidden smell)
grep -rn "user_metadata" src/ | grep -v node_modules

# Q3.5 — How does the kit gate protected routes?
grep -rn "protectPage\|requireAuth\|redirect.*login" src/ | grep -v node_modules | head -10

# Q3.6 — EXACT shape of the auth store (handbook claims derived flags that may not exist)
#         Phase 1 found: handbook claimed isAdmin/isMember/isSuperadmin; store had none.
cat src/store/useAuthStore.ts 2>/dev/null
grep -n "isAdmin\|isMember\|isSuperadmin\|isAuthenticated\|role" src/store/useAuthStore.ts 2>/dev/null

# Q3.7 — Type-safety smells in the auth store (Phase 1 found user: any)
grep -n ": any\|as any" src/store/useAuthStore.ts src/utils/get-user-role.ts 2>/dev/null
```

> **Q3.4:** inspect both authorization reads and creation-time writes. User-writable metadata must never grant privilege, including through a trigger. A protected caller alone does not make a shared metadata field trustworthy: prove that public signup cannot supply the privileged value. Record the pinned role table, resolver, trigger and caller evidence; otherwise flag the path as unsafe.

**Architect uses this to:** decide whether DATA_CONTRACT needs ANY service contracts. If the kit provides auth complete (it usually does), DATA_CONTRACT says "consume the kit's primitives directly — no wrapper." Service layer is reserved for project-specific domain logic only. Also: write the FFM's `_project/CLAUDE.md` against the store's ACTUAL shape (Q3.6) — if the handbook claims derived flags the store doesn't have, schedule adding them (or correcting the handbook) as a kit-reconciliation task, and don't write FFM code that reads flags that return `undefined`. Type smells (Q3.7) like `user: any` become reconciliation tasks (replace with the project's `User` type).

---

## SECTION 4 — Design System & Token Reality

The token mechanic depends entirely on the Tailwind major version (already captured in Q1.3). This section inventories what the kit hardcodes so the reconciliation task is scoped accurately.

```bash
# Q4.1 — Where do tokens currently live?
ls -la src/app/globals.css src/styles/globals.css 2>/dev/null
grep -l "@theme\|:root" src/**/*.css 2>/dev/null

# Q4.2 — Numbered Tailwind colors hardcoded in components (reconciliation scope)
grep -rn "slate-\|zinc-\|gray-\|red-6\|red-5\|green-6\|blue-6\|purple-6\|amber-6" src/components/ src/app/ 2>/dev/null | grep -v node_modules | wc -l
echo "--- detailed list ---"
grep -rn "slate-\|zinc-\|gray-\|red-6\|red-5\|green-6\|blue-6\|purple-6\|amber-6" src/components/ src/app/ 2>/dev/null | grep -v node_modules

# Q4.3 — Current dark mode mechanism (class vs media)
grep -n "darkMode" tailwind.config.* 2>/dev/null

# Q4.4 — Existing font setup (will the designer's font wiring conflict?)
grep -rn "next/font\|@font-face\|fonts.googleapis" src/ | grep -v node_modules

# Q4.5 — Theme toggle present? (designer themes need a working switcher)
grep -rn "ThemeToggle\|useTheme\|setTheme" src/ | grep -v node_modules | head

# Q4.6 — CSS EXTENSION MATCH: kit's entry CSS vs designer's deliverable (L14)
#   Kit shipped globals.SCSS (Sass); designer shipped globals.CSS. Mismatch = a
#   conversion task that must be scoped in Cluster 2, not discovered mid-build.
ls -la src/app/globals.* src/styles/globals.* 2>/dev/null
#   If .scss: grep for Sass-only syntax that won't survive a .css rename:
grep -n "//\|@mixin\|@include\|\$[a-z]\|&:" src/app/globals.scss 2>/dev/null
#   (nested rules + // comments are Sass-only; @apply works in both)

# Q4.7 — DARK-MODE READABILITY needs a REAL-SCREEN pass, not just style-tile (L16)
#   Style tile passed; real Slate screens were nearly unreadable (background == card,
#   borders too soft, muted-foreground too dim). The check below is OPERATOR-RUN, not
#   greppable: token-lock requires BOTH style-tile review AND an npm run dev walk of
#   the major dark surfaces — cards-on-background, secondary text, form-field
#   placeholders, borders. Flag this as a required gate BEFORE the build phase, not after.
echo "Q4.7 is an operator real-screen dark-mode check — see token-lock gate"
```

**Architect uses this to:** scope the kit-reconciliation task precisely (exact count and location of hardcoded colors), confirm the token install path, and flag font/theme-toggle conflicts before the designer's tokens land.

---

## SECTION 5 — Database & Schema Reality

Confirm what tables/triggers actually exist vs what the FFM assumes is in or out of scope.

```bash
# Q5.1 — Migration files present
ls -la supabase/migrations/ 2>/dev/null

# Q5.2 — Tables the kit ships (read the migrations)
grep -rn "create table\|CREATE TABLE" supabase/ 2>/dev/null | grep -v node_modules

# Q5.3 — Triggers/functions the kit ships (e.g. handle_new_user)
grep -rn "create function\|CREATE FUNCTION\|create trigger\|CREATE TRIGGER" supabase/ 2>/dev/null

# Q5.4 — RLS policies present?
grep -rn "policy\|POLICY\|row level security\|RLS" supabase/ 2>/dev/null | head
```

**Architect uses this to:** write DATA_CONTRACT's "tables in play / NOT in play" sections from reality, and confirm which DB functions are inherited vs need building.

---

## SECTION 6 — Skills, Security, & Environment

Confirm the runtime prerequisites the playbook's sequencing section expects.

```bash
# Q6.1 — Skills present (NOTE: resolve from the CWD Claude Code launches from)
ls -la .claude/skills/ 2>/dev/null
pwd  # confirm where Claude Code is launched — skills resolve relative to this

# Q6.2 — Security audit state
ls -la agent_docs/security/ 2>/dev/null
npm audit 2>&1 | tail -5

# Q6.3 — Required env vars (what does the kit expect?)
cat .env.example .env.local.example 2>/dev/null
grep -rn "process.env\." src/ | grep -v node_modules | grep -oP "process\.env\.\w+" | sort -u

# Q6.4 — Existing CLAUDE.md / AGENTS.md / pointer files at repo root
ls -la CLAUDE.md AGENTS.md GEMINI.md PROJECT_POINTER.md 2>/dev/null

# Q6.5 — Where does Claude Code launch from? (skills + relative paths depend on this)
#         Document this in RECOVERY.md so future sessions launch consistently.
```

**Architect uses this to:** confirm sequencing prerequisites, write the correct env-var fail-closed check list, and note the launch-CWD requirement (the skills-path nuance from Phase 1).

---

## SECTION 7 — (Retired Number)

> Intentionally vacant. Section numbers in this doc are **stable IDs, not positions** — the audit trail, F-042's resolution, and the repo-side `stark-recon` skill all cite Q-numbers (Q3.4, Q8.x, Q9.1…), so retired numbers are never reused and existing sections are never renumbered. The original §7 (Open-Ended Sweep) moved to §10 at v0.2, then to §13 at v0.4. New sections append at the end.

---

## SECTION 8 — Demo / Tutorial Scaffolding (The Cascade Trap)

Starter kits ship tutorial filler — example features demonstrating patterns — that is NOT product code. Phase 1 found a whole "posts" demo cascade: 2 services → 2 stores → 1 types file → 2 components → 3 routes → 1 util, all inherited and all dead weight. Find the WHOLE cascade up front so the Architect can scope its deletion into the FFM from the start.

```bash
# Q8.1 — Obvious demo/example feature names (posts, todos, booking, blog, sample)
grep -rln "posts\|todos\|booking\|sample\|example\|demo\|jsonplaceholder" src/ | grep -v node_modules

# Q8.2 — Third-party demo API calls (a dead giveaway of tutorial code)
grep -rn "jsonplaceholder\|dummyjson\|fakestoreapi\|reqres.in\|typicode" src/ | grep -v node_modules

# Q8.3 — Trace the full cascade for any demo feature found
#         (service → store → component → route → types → util)
#         For each demo name found in Q8.1, grep for its imports to map the fan-out:
#         grep -rn "import.*<demoName>" src/
#         Report the COMPLETE file list so deletion is one clean pass, not whack-a-mole.

# Q8.4 — Prior session logs flagging "legacy / do not touch / ignore" dirs
grep -rn "legacy\|do not touch\|DO NOT\|ignore\|deprecated" agent_docs/ 2>/dev/null | head

# Q8.5 — INHERITED CROSS-PROJECT RESIDUE (clone-debt from prior projects)
#         Phase 1 found a year-old GoHighLevel hooktest from a QR project riding along.
#         Grep for old project names, stale integrations, forgotten API stubs.
grep -rn "ghl\|gohighlevel\|hooktest\|webhook" src/app/api/ 2>/dev/null
find src/app/api -type d  # eyeball every API route — any that belong to NO current feature?

# Q8.6 — FULL ROUTE TABLE INVENTORY (run the build, read the route list day 1)
#         Phase 1's extra cruft (/demo, /template, /api/ghl, /profile) surfaced here.
#         Every route should map to THIS project or kit baseline — anything else is suspect.
# DIAGNOSTIC CHANGES: run only after explicit authorization.
# Capture command, working directory, exit code and unfiltered output.
# Without authorization, report this check as not performed; do not run it.
npm run build
```

**Architect uses this to:** scope a "demo cascade deletion" task into the FFM's Components sub-phase from day one, with the COMPLETE file list. Without this, the cascade gets discovered piecemeal mid-build (as it did in Phase 1) and the deletion becomes whack-a-mole. Knowing the full fan-out lets the deletion happen in one verified pass.

---

## SECTION 9 — FFM Packaging & Compile Scope

**Q9.4 — Build/deployment exclusion.** Identify the applicable build/deploy input exclusion mechanisms for `agent_docs/**` (for example `.dockerignore`, `.gcloudignore`, `.vercelignore` or the platform equivalent). Verify the actual built image/bundle or deployed artifact excludes it. Record command, working directory, exit code and unfiltered safe output. Compile/test exclusion alone does not prove production exclusion. Follow `DEPLOYMENT_PLAYBOOK.md` §4; do not infer cloud authorization from this question.

The FFM itself can break the build if its template files land inside the TypeScript or test scope. Phase 1 found the FFM's `.ts` template stubs (in `skills/templates/` and `_design/tokens/`) caught by `tsc --noEmit`, throwing 3 phantom errors in non-source files.

```bash
# Q9.1 — Does tsconfig exclude the FFM/agent_docs tree?
cat tsconfig.json | grep -A10 '"exclude"'
#   If agent_docs/** (or wherever the FFM lands) is NOT excluded, the FFM's
#   .ts template stubs will be compiled and may throw phantom errors.

# Q9.2 — Does the test runner scope exclude agent_docs?
grep -rn "include\|exclude\|testMatch\|dir" vitest.config.* jest.config.* 2>/dev/null

# Q9.3 — What .ts/.tsx files live under agent_docs (would-be compile targets)?
find agent_docs -name "*.ts" -o -name "*.tsx" 2>/dev/null | grep -v node_modules
```

**Architect uses this to:** declare and verify compile/test exclusions, build/deploy input exclusions and inspection of the actual produced artifact. A non-compiled extension prevents compilation only; it does not prove deployment exclusion. Keep module/QAM/evidence records under `agent_docs/` and preserve required evidence.

---

## SECTION 10 — (Retired Number)

> Intentionally vacant — see the §7 note. The Open-Ended Sweep held this number from v0.2 until v0.4 moved it to §13.

---

## SECTION 11 — Nav & Auth-State Patterns (The Landing/Nav Lessons)

The landing page took 3 iterations and the marketing nav stranded logged-in users. These checks turn those scars into upfront questions.

```
# Q11.1 — Marketing nav vs portal nav are DIFFERENT (L19)
#   Marketing nav has real destinations (esp. Log in) → needs a mobile hamburger.
#   Portal nav for placeholder portals (no Dashboard/Settings yet) → logo + user menu.
#   For EACH nav surface, ask separately: does it have real mobile destinations?
#   Marketing-nav default = hamburger REQUIRED.

# Q11.2 — Every navbar has a theme toggle (L20)
#   Theme is a UX setting that applies everywhere, including logged-out marketing pages.
#   Confirm the theme toggle is reachable from EVERY navbar surface, not just portals.

# Q11.3 — Every public/marketing route has an auth-state region DEFINED (L22)
#   "No auto-redirect" does NOT mean "no auth awareness." A logged-in user landing on /
#   must still see they're logged in + reach their portal + log out.
#   For each public route, define: what shows logged-IN vs logged-OUT? (Not just routing.)
#   Distinguish ROUTING-behavior (don't bounce them) from UI-STATE (reflect their state).

# Q11.4 — Complex split-hero transforms at lg:, not md: (L18)
#   A two-column hero (copy + visual-that-needs-width) squishes in the 768-1023 range.
#   For any split hero, the side-by-side engages at lg: (1024px). md: is for text/size
#   transitions only, not layout pivots. Ask: what breakpoint engages side-by-side?
#   If md: → flag for review.

# Q11.5 — "Always-visible" mobile controls sit OUTSIDE the hamburger (L21)
#   Navigation belongs in the menu; controls (theme toggle, search, avatar) stay at top
#   level for single-tap reach. Confirm the split.
```

**Architect uses this to:** spec navbars correctly the first time — marketing nav gets a hamburger + theme toggle + auth-state region; split heroes default to `lg:`; controls stay outside the menu. Prevents the 3-iteration landing churn.

---

## SECTION 12 — Verification Rituals (What Piecewise Gates Miss)

Each gate passed in isolation; the continuous SP5 walk caught a real bug no gate's grep could. These checks bake the verification lessons into the FFM upfront.

```
# Q12.1 — Every grep-verifiable gate runs its grep AT SP-CLOSE (L17)
#   "Sample-check one file then trust the rest" is BRITTLE — it hid 5 numbered-color
#   sites in shadcn primitives until SP-close panic. For any gate with a grep-verifiable
#   predicate (no numbered colors, no user_metadata, no forbidden imports), the grep
#   RUNS at SP-close as a standard step. Sample-then-trust is DISALLOWED for these.

# Q12.2 — Boot/instrumentation checks verify PROCESS STATUS, not just logs (L28)
#   Turbopack prints "✓ Ready" BEFORE an instrumentation throw propagates — looks like
#   the server started when it actually died. Verify with curl/port-check that the
#   process is actually gone, plus a success-log line ("✓ Environment validated") as the
#   only unambiguous "hook fired + passed" signal.

# Q12.3 — SP5 includes a SEAM-CHECK: walk every transition in every auth state (L29)
#   Gates measure components in isolation; bugs live in the SEAMS. The continuous walk
#   (login → role → portal → gate → logout → back to /) caught the auth-stranding bug.
#   SP5 ritual = "navigate every surface in every auth state," not just the happy path.

# Q12.4 — Between deletion batches, rm -rf .next before tsc smoke (L25)
#   Stale .next/types/validator.ts references deleted routes → false-failure noise
#   indistinguishable from real orphaned imports. Clear .next before per-batch tsc.

# Q12.5 — Run pre-deletion test baseline FRESH; don't trust historical counts (L26)
#   A prior session log was 3 tests behind. Predict from a fresh run, not history.
```

**Architect uses this to:** write verification sub-phases that close gates honestly (grep-at-close), prove boot checks correctly (process status), and make SP5 a real seam-check instead of a formality.

---

## SECTION 13 — Open-Ended Sweep

The questions above are the known traps. This section catches the unknown ones.

```bash
# Q13.1 — Full src/ tree (2 levels) so the Architect sees the actual shape
find src -maxdepth 2 -type d | sort

# Q13.2 — Anything in the repo that contradicts what the operator described?
#         (Claudy reports any surprise: stale scaffolding, unexpected dirs,
#          vestigial template strings, half-finished features)

# Q13.3 — Vestigial template residue (starter kits leave these)
grep -rn "Your Company\|Acme\|TODO\|FIXME\|placeholder\|lorem ipsum" src/ | grep -v node_modules | head -20

# Q13.4 — The cn() helper every component depends on
cat src/lib/utils.ts 2>/dev/null | grep -A5 "export.*cn"
```

**Architect uses this to:** catch the things no questionnaire anticipated. The open-ended sweep is where the NEXT lesson gets discovered.

---

## Recon Report Format (What Claudy Returns)

Claudy answers in this structure:

```
## RECON REPORT — <project> <phase>

### Section 1 — Stack Versions
- Next.js: <actual>
- React: <actual>
- Tailwind: <actual> → token mechanic: <HSL/config OR @theme/OKLCH>
- TypeScript: <actual>
- Node: <actual or "not pinned">

### Section 2 — Kit Structure vs Handbook
- Handbook claims verified: <list confirmed>
- DRIFT FOUND: <list every handbook claim that's false, with reality>
- Existing src/services/: <contents or "empty/absent">

### Section 3 — Auth Pattern
- User read via: <actual mechanism>
- Role resolved via: <actual mechanism + file>
- Existing auth service: <yes/no — if yes, what>
- user_metadata role smells: <count + locations, or "none">

### Section 4 — Design Reality
- Tokens live in: <path>
- Hardcoded numbered colors: <count> in <files>
- Dark mode: <class/media>
- Font setup: <current>
- Theme toggle: <present/absent>

### Section 5 — Database
- Migrations: <count>
- Tables shipped: <list>
- Triggers/functions: <list>
- RLS: <present/absent>

### Section 6 — Skills/Security/Env
- Skills present: <list + which CWD they resolve from>
- Security audit: <state>
- Required env vars: <list>
- Launch CWD: <path>

### Section 8 — Demo / Tutorial Scaffolding
- Demo features found: <list>
- Full cascade per feature: <complete file list — services, stores, components, routes, types, utils>
- Third-party demo APIs: <list, e.g. jsonplaceholder>
- Recommended deletion bucket: <which sub-phase>

### Section 9 — FFM Packaging
- tsconfig excludes agent_docs/**: <yes/no — if no, FLAG>
- Test runner excludes agent_docs: <yes/no>
- .ts files under agent_docs that would compile: <list>

### Section 13 — Surprises
- <anything unexpected — this is the highest-value section>
- cn() helper present + standard: <yes/no>

### Recommendation to Architect
- <any FFM authoring implications Claudy spotted>
- <every handbook claim that proved FALSE against the filesystem>
```

---

## Version History

| Version | Date | Changes |
|---|---|---|
| 0.1 | 2026-06-05 | Initial questionnaire, authored mid-Phase-1 from the four conflicts surfaced at Cyber Pharma v1 Phase 1 Discovery (Next 15/16, authService wrapper, app-role.ts ghost file, unexpected src/services/). Seven sections + recon report format. |
| 0.2 | 2026-06-05 | Folded in mid-Phase-1 Sub-Phase 2/3 findings. NEW §8 (demo/tutorial scaffolding cascade — the posts demo fan-out), NEW §9 (FFM packaging / tsconfig compile scope — phantom tsc errors from template stubs). Added Q3.6 (auth store actual shape), Q3.7 (type-safety smells like user:any), Q10.4 (cn() helper check). Elevated the **"handbook is aspirational, not literal"** meta-lesson to the opening — FOUR handbook claims proven false by end of Phase 1. Open-ended sweep renumbered §7→§10. |
| 0.3 | 2026-06-05 | Mid-Cluster-3 additions. Q1.7 (test runner check, Jest vs doctrine Vitest). Q8.5 (inherited cross-project residue, the year-old QR-project GHL hooktest fossil riding along through clones). Q8.6 (full route-table inventory day 1, surfaces /demo /template /api/ghl /profile cruft). |
| 0.4 | 2026-06-07 | Full Run 001 integration (34 lessons). NEW Section 0 (Day-1 Ground-Truth Sweep — the meta-lesson: handbook is aspirational, verify everything on disk first; consolidates L1/L5/L6/L7/L8/L9/L24/L32). NEW Section 11 (Nav & Auth-State Patterns — marketing-vs-portal nav L19, every-navbar-theme-toggle L20, auth-state region L22, split-hero lg: L18, controls-outside-menu L21). NEW Section 12 (Verification Rituals — grep-at-close L17, process-status check L28, SP5 seam-check L29, rm .next between batches L25, fresh test baseline L26). Section 4 gained CSS-extension match (L14) + dark-mode real-screen check (L16). Open-Ended Sweep renumbered to Section 13. |
| 0.5 | 2026-07-07 | **Wave 2A (audit sync).** Standard header block (F-018); recon's place stated: Blueprint lifecycle Phase 0 + FFM Stage 0; mutual pointers with ARCHITECT_PLAYBOOK §2 Recon Mode and the `stark-recon` skill — this doc named as the skill's source content (F-024). Numbering repaired without renumbering (F-023): §7 and §10 marked as retired numbers with the stable-ID rule stated (numbers are IDs, not positions — external citations of Q3.4/Q8.x/Q9.1 stay valid); §13's questions relabeled Q10.x → Q13.1–Q13.4; Recon Report Format "Section 10 — Surprises" → "Section 13 — Surprises". Q3.4 gained the F-042-resolution nuance box (kit is table-based; smell = authz read from user_metadata or client-writable role write path; metadata = creation-time transport only, via protected channel). Content otherwise untouched — scars preserved. |
| 0.6 | 2026-10-18 | Factory DocSet sync: approved workflow/security/reference corrections; preserved original; explicit exclusions per doctrine-part2 map. IDs: FC-001, FC-005, FC-007, FC-014, FC-033, FC-034, FC-069, MC-02, MC-04, MC-13, RUL-03, RUL-12, W17 |

---

## Lessons Backlog (Promote To Sections As They Recur)

> When a NEW conflict surfaces at a Discovery gate, add a question here that would have caught it. When the same conflict recurs across two runs, promote it into a numbered section above.

Phase 1 lessons already promoted into numbered sections (v0.2): demo scaffolding cascade (§8), FFM packaging/tsconfig (§9), auth-store shape + type smells (§3.6/3.7).

Still in backlog (watch for recurrence):
- **Handbook-as-fiction frequency** — Phase 1 hit FOUR false handbook claims. If the next run also finds multiples, promote a dedicated "Handbook Audit" section that walks every handbook claim against disk systematically, not opportunistically.
- **Prior-session-log mining** — the kit's prior build logs flagged "legacy/do not touch" dirs. Q8.4 covers this, but if more lives in old session logs, consider a dedicated session-log recon question.
- _(Phase 1 retrospective will add more here at close)_

---

🛡️ **The Architect authors blind no more. Claudy verifies ground truth; the Architect writes from facts.**
