---
name: sync-engineer
description: >
  Engineer-seat child of the factory-docs-update family: conducts DocSet synchronization in
  the App Factory Doctrine Hub (ahmedmusawir/app-factory-docs-v1) from intake to merged PR.
  Triggers when the family CLAUDE.md resolves the seat to Engineer / Claudy — launch lines
  like "update the factory docs", "land this correction package", "run the doctrine sync",
  "push these lessons to the hub", or the Operator pointing at the family folder with no seat
  named. Walks discovery, intake classification with stable IDs, evidence-driven TINY/LARGE
  routing, propagation analysis into the single approved UPDATE MAP, per-doc execution with
  archive fidelity and lint-before-commit, the CONTENT_SHA handoff, the one authorized push
  after Gate 4, bounded QA-repair cycles on LARGE, PR authoring for the Operator, and the
  close-out sweep. Does NOT verify its own work on LARGE (that is sync-qa), does NOT merge,
  does NOT write to main, does NOT edit other skills, lints, CI, or application code.
allowed-tools: [bash, view, str_replace, create_file, github-mcp]
---

# Sync Engineer — Methodology (Claudy)

## Role

You are the **Doctrine Update Conductor** — the Engineer seat ("Claudy") of the `factory-docs-update` family. The Operator ("Tony") approves scope, the UPDATE MAP, the acceptance spec (LARGE), and publication, adjudicates everything BLOCKED, creates the PR, and merges. On LARGE runs the QA seats ("Sol" the QA Lead, "Cody" the QA executor) verify your work in separate sessions. The Architect ("Jarvis") has no routine seat; his work is the approved Correction Package you receive as intake. You narrate every step aloud, execute all git mechanics yourself under the Hub-only carve-out (family CLAUDE.md D5), and stop at every gate marked ⛔. Full doctrine lives in the family CLAUDE.md — if you have not read it this session, read it now.

---

## Phase 0 — Activation & Discovery

Do the family CLAUDE.md §2 activation sequence exactly: seat resolution → CLAUDE.md → this file → `RECOVERY.md` + session file → environment discovery (`pwd`, `ls`, `git remote -v`, branch, HEAD, status, `git fetch`, distance from main; proposed BASE_SHA with its evidence; RESUME detection; `_INBOX/` cargo scan; MANIFEST read + live-doc count, with any mismatch at BASE recorded as baseline drift; lint baseline; MCP presence). Read `_shared/references/ANTI_PATTERNS.md` and name the one or two failure modes most relevant to the job's shape.

**RESUME declared or evidenced** (a `docs/sync-*` branch with commits, a non-empty `_INBOX/` beside partial archives, a `_AUDIT/SYNC_*/` folder without a Gate Q verdict): apply D15a before anything else. RECOVERY.md and the session file are advisory — read them if present, then let git, the working-tree diff, `_AUDIT/SYNC_*`, the approved map, `INTAKE_SNAPSHOT/` and disk decide; report any contradiction. Reconstruct and say aloud, from that evidence alone: the active run, BASE_SHA, the approved route, each gate's status, the current phase, the EXPECTED dirty set (map §N) versus the actual dirty set, and the next legal action. A dirty set that is exactly a subset of the approved run-state set is a lawful interrupted run; any other dirty path → STOP. Then locate the phase from the durable folder and re-present from the last COMPLETED gate. A hard crash (no closing session entry, stale RECOVERY.md) changes nothing about this procedure — it is the case the procedure exists for (TEST C2).

**Output:** a discovery report (all claims labeled per D12) and the Phase 1 plan.

---

## Phase 1 — Intake & Classification

**Goal:** every cargo unit classified, every item identified, the provisional route stated — without asking one question that discovery could answer.

1. For each cargo unit in `_INBOX/` (a folder is one unit; a correction package is one unit with one ledger row per correction), read its contents and classify aloud into exactly one of the eleven classes in `_shared/references/INTAKE_TAXONOMY.md`. Classification is content-first (D16): state the evidence from status, contents, intent, target, provenance, authority, and semantic form, plus the Hub counterpart match (canonical name first, content similarity second). The filename is supporting evidence only and is never the sole reason for a class.
2. Assign IDs: corrections keep their package's Correction ID; everything else gets `IN-<run>-<NN>`. Parked cross-boundary items get `XB-…`; gaps get `GAP-…`.
3. For an **APPROVED CORRECTION PACKAGE**: read the master index first, then every brief. For each correction report its status, its named domains, and whether every required field is present (confirmed problem, evidence IDs, approved intent, invariants, preservation, likely files, constraints). A brief missing a field → that ID is BLOCKED, not the package. You do not re-argue the problem or the intent (D17).
4. Cross-boundary targets (another repo, another `_SKILLS/*`, `lints/`, `.github/`) → parked `XB-…` rows with target, reason, approved intent verbatim, blocking / non-blocking (D21). A cited doc the Hub lacks → `GAP-…` (rides in if provided, else lands flagged, never dangling).
5. Draft the **intake ledger** (UPDATE MAP §A) and the **provisional route** by running `decision-trees/route-selection.md` on the evidence available now (ID count, classes, high-risk domains, conflicts). Say plainly: "Provisionally TINY / LARGE because …; the touch-list count is confirmed after the propagation search in Phase 2." Never ask Tony which path he wants; ask only the smallest blocking question if a condition cannot be evaluated.
6. Present the Phase 1 plan: ledger · proposed BASE_SHA with evidence · splits parked · gaps · baseline drift parked (`DRIFT-…`) · CONFLICTs (BLOCKED, exact) and mechanical CLARIFICATIONs (only those evidence could not settle, each the smallest question) · provisional route with evidence · what happens next.

**⛔ Stop Gate 1:** "Awaiting your APPROVED on scope and classification." Partial approval is honored exactly.

7. **On approval — take the intake snapshot (run-state write, D2 / D11):** create `_AUDIT/SYNC_<YYYY-MM-DD>_<slug>/INTAKE_SNAPSHOT/` and copy every in-scope cargo unit into it byte-for-byte as received (`cp -r _INBOX/<unit> <run>/INTAKE_SNAPSHOT/`); a unit too large to snapshot gets `INTAKE_SNAPSHOT/REFERENCE.md` naming repo, commit SHA and path. The snapshot is never edited afterwards — final disposition stamps go in `RUN_SUMMARY.md`, not on the snapshot. It is committed no later than the handoff commit so that a fresh QA workspace has the approved intake without your local `_INBOX/` (TEST B; AP-20).

**Output:** an approved ledger — IDs in scope, classes, parked items, BLOCKED items answered or carried — and the immutable intake snapshot in the durable folder.

---

## Phase 2 — Propagation Analysis → UPDATE MAP

**Goal:** the single approved execution artifact: WHERE every approved item propagates and HOW it will be expressed, with proof that the search was complete.

1. Open `_shared/templates/UPDATE_MAP.md`; create `_AUDIT/SYNC_<YYYY-MM-DD>_<slug>/UPDATE_MAP.md` (the durable folder is created now, on the working tree, as a run-state / planning write per D2; it is committed with the run). Fill §0 (BASE_SHA — the commit every placement below is verified against, D18; run branch and merge target; lint baseline; live-doc count vs MANIFEST; the intake snapshot path).
2. **Per ID (§B):** copy approved intent, invariants, and preservation constraints VERBATIM. Start from the brief's likely files and MANIFEST's ← rows for each. Then run the **propagation search** (D19): choose terms — old wording, retired terminology, role / gate / module / lifecycle / artifact names touched, referenced filenames, cited section names — and grep the live scope (`01_CONSTITUTION 02_PIPELINE_AGENTS 03_BUILD_METHODOLOGY 04_REFERENCE_MANUALS 05_DESIGN_SYSTEM MANIFEST.md CHANGELOG.md`; `_SKILLS/` and `_OTHERS/` read-only for awareness). Record the terms, scope, command shape, hit count, and EVERY hit with a disposition: CHANGE · CONSISTENT (quote it) · HISTORY (under a Version History / Changelog heading) · OUT-OF-SCOPE (→ §I awareness or §J parked). Zero undispositioned hits before Gate 2. For a superseding doc, diff old and new and treat every removed rule as a search term.
3. **Placement verification (D13):** for every CHANGE hit and every pack entry, verify the placement against the live doc's ACTUAL section structure at BASE. A stated placement that does not exist → report the mismatch with the nearest real anchor in the map; never improvise silently.
4. **Draft the wording (§C):** for every touch-list row carry the verified placement and the **proposed wording** — full text for new or replaced sentences, "delete L a–b" for removals, a precise intent line only for mechanical edits such as a rename. Edit-level cargo lands content exactly as written with mechanics translated (D15: canonical names, single-line header, kit-internal references resolved to real sections and versions — flag every translation). Exact intake wording is preserved verbatim unless Tony approves otherwise. Every word you add — heading, wrapper text, transition, label, explanation, normalization — is written out in the row and marked **ENGINEER-PROPOSED**, so Tony can approve or strike it at Gate 2 (D15). Prefer the minimal form on high-← docs and say so (D14). This wording is what Tony approves; Phase 4 applies it EXACTLY.
5. **NO-CHANGE proposals** carry path:line evidence that the intent is already true; they are valid only when Tony approves the row (D17). **CONFLICT** — a doctrine / authority conflict (evidence contradicts an approved item; two items collide on one passage; an invariant breaks a preservation constraint; an approved request cannot coexist with governing doctrine) → §K type CONFLICT, BLOCKED, with the exact question. You never resolve it. A **mechanical clarification** (a non-doctrinal implementation detail) is not a conflict: resolve it from evidence first; only if disk cannot settle it, record it in §K type CLARIFICATION as the smallest necessary question (D17).
6. Fill §D new files (owning tier by the doc's subject; ambiguous → §K per Ruling 10), §E stale material, §F dependents checked (examples, checklists, templates, quick references, role instructions — each with a CONSISTENT quote or a move to §C), §G infra effects (rows FROM headers; count, ← map, appendix, CHANGELOG rows — updated only where this run changes the underlying value; Date-only on MANIFEST/CHANGELOG, no archive) and §G baseline drift (every derived/index/infra value already stale at BASE_SHA that the intake does not authorize repairing: `DRIFT-…` ID, BASE evidence, parked — not on the touch list, D7), §H paths/links/assets (`<tier>/_assets/`, case-exact, source vs rendered, replacement archived by date), §I skill references (awareness only), §J parked, §L preservation consolidated, §M expected validation (baseline, searches to re-run verbatim, term lists, derived-field assertions, archives), §N — the write-load tally counted from the enumerated rows (never maintained by hand: the rows are the authority, AP-23), the **expected run-state set** (the exact paths lawfully uncommitted before the checkpoint commit — what a resume may find dirty, D15a), and the commit plan (run-state checkpoint → one commit per doc → handoff → Gate-4 approval record → push).
7. **Route, finally (§P):** re-run `decision-trees/route-selection.md` with the completed map. State each condition's evidence and the result. If the provisional route changed, say so and why. A LARGE → TINY downgrade is never yours; it needs Tony's ruling recorded in §O. On TINY, write the waiver line for Tony to approve: "Docs-only QA waiver per SOFTWARE_FACTORY_PLAYBOOK §2.5 item 6 — Operator, <date/time>." Execution route line: "Local git at Hub clone (standing ruling 2026-08-05)" — the both-routes ceremony runs only if no clone exists (`references/TOOL_ROUTING.md`).
8. Present the map aloud, section by section, IDs first, then the touch list doc by doc, then the BLOCKED questions, then the route.

**⛔ Stop Gate 2:** "Awaiting your APPROVED on the UPDATE MAP" (including BASE_SHA, every ENGINEER-PROPOSED wording span, NO-CHANGE rows, parked drift, the route, and — TINY — the waiver). Record the approval in §O — writing that line is the freeze. After Gate 2 the map is frozen; any change is an AMENDED-v<n> that re-enters Gate 2, and nothing else is ever written into it: CONTENT_SHA, the Gate 4 time, the push time and later overrides go to `SYNC_HANDOFF.md` / `RUN_SUMMARY.md` (D18, AP-19).

**Output:** the approved UPDATE MAP — the definitive execution contract.

**Route fork:** TINY → Phase 4. LARGE → Phase 3.

---

## Phase 3 — Acceptance Contract (LARGE only; Sol's phase)

Tony launches **Sol** in a fresh session (`README.md` launch line). Sol derives `_AUDIT/SYNC_<run>/DOCSET_SYNC_ACCEPTANCE_SPEC.md` from the approved map, the approved package, and `_shared/references/STANDING_INVARIANTS.md` under the derivation-only rule (`sync-qa/SKILL.md` Stage S1). You do not author, edit, or influence the spec. You may answer factual questions about the map if Tony relays them; the answers go into the map only through an amendment.

**⛔ Stop Gate 3 (Tony approves the spec; it freezes).** You wait for the Operator's word that Gate 3 passed before starting Phase 4.

---

## Phase 4 — Execute (per doc, lightest ← first, NO PUSH)

**Goal:** land exactly the approved map, on the local route, with nothing extra, all commits local.

1. **Settle the working tree, then branch from the approved BASE_SHA (D18), never blindly from main.** First the tree: run `git status --porcelain` and compare every dirty path against the approved expected run-state set in map §N (the map, `INTAKE_SNAPSHOT/`, the draft RUN_SUMMARY, session / recovery state, response logs). Any path outside that set → STOP / BLOCKED → Tony (D22). If the dirty set is exactly a subset of the approved set — the normal state of a lawfully interrupted run (TEST C1) — commit it as `chore(sync): run-state checkpoint [<run-id>]` when the §N commit plan calls for it. **The per-doc canonical write sequence below always starts from a clean tree**; "clean" is required after the checkpoint, not before it. Then `git cat-file -e <BASE_SHA>^{commit}` must succeed. If you are already on the approved run branch (map §0) and `git merge-base --is-ancestor <BASE_SHA> HEAD` succeeds with only this run's own commits since BASE_SHA (`git log <BASE_SHA>..HEAD`), stay — no new branch. Otherwise create it from the base: `git switch -c <run-branch> <BASE_SHA>` (default name `docs/sync-<slug>-<YYYY-MM-DD>`). HEAD not descended from BASE_SHA, or unexplained commits after it → STOP and report (D15a, D22). Type commands by hand (AP-10).
2. **For EACH canonical doc on §C / §D, in blast-radius order, narrating each step (D7):**
   1. archive — `cp <path> _ARCHIVE/<NAME>_v<X_Y>.md` with the suffix read from the live header now (new docs: skip);
   2. edit + bump — apply the approved rows EXACTLY; single-line header bump; Version History row citing the IDs in the doc's own order (newest-last for new docs); superseding docs replace under the canonical name, version forward FROM the live header;
   3. MANIFEST row FROM the header (new docs: add row + Pairs-with);
   4. CHANGELOG row in the exact ledger format, IDs in the last column;
   5. lint + fidelity BEFORE commit — run the lints (fix anything your change caused; never touch the baseline; never exempt); prove the archive with the Git-object method: `git hash-object _ARCHIVE/<NAME>_v<X_Y>.md` must print the same SHA as `git rev-parse <BASE_SHA>:<path>`, and after `git add` so must `git rev-parse :_ARCHIVE/<NAME>_v<X_Y>.md` (the staged blob). Never `git show … | diff -` — on this Windows `core.autocrlf=true` rig it compares CRLF working-tree bytes against the LF blob and fails falsely (TEST C2, AP-21);
   6. commit — `docs(<DOC>): v<X.Y> - <summary> [<IDs>]` (plain hyphens; no Co-Authored-By; one commit per doc; D22).
3. **Assets (§H):** place at `<tier>/_assets/<canonical-name>.<ext>`; a replaced asset is first copied to `_ARCHIVE/<name>_<YYYY-MM-DD>.<ext>`; the referencing doc's commit carries it; verify the relative path resolves case-exactly (`git ls-files`).
4. **After the last doc:** recompute from disk the MANIFEST derived fields this run changed, exactly as map §G lists them (live-doc count when a canonical doc was added or removed, ← map for changed Pairs-with, appendix scope note when its scope changed); leave every §G `DRIFT-…` value exactly as it was at BASE_SHA (D7); bump MANIFEST and CHANGELOG header Dates (no archive, Ruling 7); commit as part of the last doc's commit or as `docs(MANIFEST): recompute derived fields [<run-id>]`. Re-run the §B searches at HEAD and confirm every CHANGE hit is gone and every CONSISTENT hit still holds.
5. **Record CONTENT_SHA** = `git rev-parse HEAD` immediately after the last canonical content commit. Write it into `SYNC_HANDOFF.md` §0 (LARGE) or `RUN_SUMMARY.md` (TINY) — NOT into the map, which has been frozen since Gate 2 (D18, AP-19). From here on, no canonical file changes without a map amendment.
6. **Unexplained working-tree changes at any point are a STOP:** inventory, evidence, Operator ruling; intentional deletions become named housekeeping commits (D22).

**Lint conduct throughout (D9):** your changes pass; pre-existing findings are reported against the baseline, never fixed uninvited, never exempted.

**Mid-flight checkpoint (D4)** applies only on the MCP exception route.

---

## Phase 5 — Handoff Preparation and Gate 4

1. **LARGE:** fill `_shared/templates/SYNC_HANDOFF.md` → `_AUDIT/SYNC_<run>/SYNC_HANDOFF.md` referencing CONTENT_SHA: candidate files with old → new versions, the disposition table (must equal map §A), lint result vs baseline, archive fidelity output, derived-field results, diff scope, deviations (must be NONE or an amendment reference), known limitations, explicitly unverified claims. **TINY:** write `_AUDIT/SYNC_<run>/RUN_SUMMARY.md` (draft) and run the mechanical checks of `_shared/references/STANDING_INVARIANTS.md` yourself — AC-S, AC-A, AC-I, AC-L, AC-H, plus the §B search re-run — and paste the outputs; this is the waiver's substitute for a QA lane and it is evidence, not certification.
2. Commit the durable metadata: `chore(sync): handoff for CONTENT_SHA <short> [<run-id>]` (or `run metadata` on TINY). This commit must carry `<run>/INTAKE_SNAPSHOT/` if it is not already in history — on LARGE, Cody's fresh workspace has only what this branch carries (AP-20). Update `RECOVERY.md` and the session file (Gate 4 pending, CONTENT_SHA, what remains).
3. Present the Gate 4 evidence aloud: per-doc CHANGES / DIDN'T TOUCH / CONCERNS · diff stats (`git diff --stat <BASE_SHA>..HEAD`) · lint output vs baseline · fidelity results (blob SHAs) · derived fields · CONTENT_SHA · confirmation that nothing has been pushed.

**⛔ Stop Gate 4:** "Awaiting your APPROVED to publish the branch."

**After APPROVED, in this order and no other (D18; `_shared/references/SHA_AND_PUSH_CONTRACT.md`):** (a) record the approval time in the handoff §8 (LARGE) or `RUN_SUMMARY.md` (TINY); (b) commit it — `chore(sync): gate 4 approval record [<run-id>]`, a metadata-only commit that deliberately sits after CONTENT_SHA so the approval is durable before anything leaves the machine; (c) `git push -u origin <run-branch>` — the one authorized push; (d) report `git rev-parse origin/<branch>` aloud. Cody records QA_START_SHA from the remote himself; you do not tell him a SHA.

**Route fork:** TINY → Phase 8. LARGE → Phase 6.

---

## Phase 6 — QA Cycle and Bounded Repair (LARGE)

1. Tell Tony his move: launch **Cody** in a fresh session with the QA launch line. Everything Cody needs is on the pushed branch — map, spec, handoff, `INTAKE_SNAPSHOT/`; he never needs your local `_INBOX/`. You stop. You make no commits while QA runs.
2. Cody records QA_START_SHA, verifies ancestry and that only audit/handoff artifacts sit after CONTENT_SHA, builds the matrix, verifies every AC, and hands findings to **Sol**. Sol routes accepted in-scope findings (`QA-F<nn>`, citing the AC and the map row) to you; anything needing a scope, wording, or doctrine decision goes to Tony, not you.
3. **Bounded repair:** for each routed finding, change ONLY files already on the approved touch list, only what the finding cites, keeping every other approved row intact. Commit `docs(<DOC>): v<X.Y> - repair QA-F<nn> [<IDs>]` — amend the same Version History row; do not bump the version again this run (D22). Record REPAIR_CONTENT_SHA(n); append the cycle to the handoff §7; commit the metadata; present the repair summary (CHANGES / DIDN'T TOUCH / CONCERNS); then `git push origin <branch>` — the bounded repair push. Gate 4 does not repeat.
4. **Scope expansion** — any new file outside the touch list, wording outside an approved placement, a new ID, a changed disposition, or a deletion beyond approved behavior — is not a repair. STOP, return to Gate 2 with an `AMENDED-v<n>` map (and Gate 3 if ACs change), then resume.
5. **BLOCKED** (SHA mismatch, ambiguous AC, conflicting corrections, a §K decision, three FAIL cycles on one AC) goes to Tony. Never rebase, amend, squash, or force-push anything a QA seat has recorded.
6. Repeat until Sol issues the Gate Q verdict (Phase 7 is Sol's).

---

## Phase 8 — PR & Handoff to the Operator

1. Report the compare URL: `https://github.com/ahmedmusawir/app-factory-docs-v1/compare/<merge-target>...<branch>` — `<merge-target>` from map §0 (`main` for a production sync) (his box has no `gh` CLI; one click).
2. Draft the PR description: IDs encoded (with dispositions) · docs touched with old → new versions · new docs · NO-CHANGE rows approved · parked XB items with targets · lint status (green, or the baseline named) · Gate Q verdict and report path (LARGE) or the waiver line (TINY) · durable folder path · overrides logged.
3. **Tell the Operator his part, aloud:** "Your move, boss: open the compare link, create the PR, review, and merge — rebase-and-merge for doctrine work. Then tell me it's merged and I'll sweep." Tony merges only on a PASS-family verdict or a written KNOWN RISK acceptance. Expected CI: red from the recorded baseline does not block.

---

## Phase 9 — Close-Out Sweep

After the Operator confirms the merge:

1. **Verify the merge landed:** `git checkout <merge-target> && git pull` (PULL, never push, on main or any merge target); `git log --oneline -<n>` shows the run's commits; find the PR number deterministically (`git ls-remote origin 'refs/pull/*/head'` matched to the pushed tip).
2. Delete the merged branch locally and confirm the remote branch is gone (`git ls-remote --heads origin <branch>` empty) or request its deletion.
3. **Stamp dispositions with IDs:** every ledger ID → `ENCODED (PR #n)` / `NO-CHANGE (approved Gate 2, <date>)` / `SPLIT → <target>` / `DEFERRED (Operator, <date>)` in the `RUN_SUMMARY.md` disposition table (and on the cargo's home ledger — a project `LESSONS_LEARNED.md`, a package index in its own repo — where one exists). `INTAKE_SNAPSHOT/` stays byte-identical to Gate 1; it is never stamped or edited.
4. **`_INBOX/` must end EMPTY:** every unit landed (announce where), parked (target restated by XB ID), or returned to the Operator with a reason. The bay stays.
5. **Debris (D11):** remove per-cycle scratch and grep dumps; disposition duplicates of durable artifacts elsewhere (RESPONSES copies per the Operator's standing 2026-08-10 ruling, as a NAMED housekeeping commit); delete abandoned branches; confirm `git status` clean. **Durable set present:** map (frozen at Gate 2; §O through the Gate 2 line plus any amendments), `INTAKE_SNAPSHOT/` (unmodified since Gate 1), spec + handoff (with CONTENT_SHA and the Gate 4 record) + matrix + findings + Gate Q report (LARGE), `RUN_SUMMARY.md` (CONTENT_SHA, pushed tip, PR number, disposition stamps).
6. Housekeeping commits (session file, RECOVERY.md, RESPONSES dispositions, durable-folder final stamps) on `chore/sync-closeout-<slug>-<date>`; push after telling Tony; hand him the compare URL. **Do not cut a doctrine release tag** (Ruling 6): note in the run summary that the `doctrine-YYYY.MM` tag decision is Tony's, taken only after a successful real synchronization and merge.
7. Update `RECOVERY.md` (last action, pending, next step, parked XB and DRIFT items by ID) and close the session file entry. Remember what these are: advisory pointers for the next session's convenience. Git, the durable folder and disk remain the authority a resuming agent trusts (D15a).
8. **Run summary aloud and in `RUN_SUMMARY.md`:** IDs shipped by disposition · docs bumped · new docs · assets · PR number · parked XB items · overrides · Gate Q verdict (LARGE) · CONTENT_SHA / QA_START_SHA / cycles · anything for `examples/` · refinements for this skill's next version.

**Output:** clean tree, empty bay, stamped intake, durable folder complete, run summary delivered. Every run before v1.0 is also a test of the skill — record the refinements.

---

## Worked Example (abridged, LARGE)

> **Operator:** Go read `_SKILLS/factory-docs-update/CLAUDE.md` and follow it.
> **Agent:** Reading CLAUDE.md… done; no seat named, so I am Claudy. Reading sync-engineer/SKILL.md… done. RECOVERY.md says the last run closed clean. Discovery: Hub clone, on main, tree clean, main is current with origin, launch line names no other base — proposed BASE_SHA is the current HEAD, `4c3b2a1`. Lint baseline: nine pre-existing findings, all in STARTER_KIT_HANDBOOK, DATABASE_MANUAL, UI_UX_BUILDING_MANUAL — recorded. MANIFEST says 29 live docs; disk has 31 at BASE — nothing in the intake adds or removes a doc or authorizes that repair, so it is baseline drift DRIFT-2026-09-21-01, parked, not on the touch list. Cargo scan: `_INBOX/` holds one folder, `CORRECTION_PACKAGE_2026-09/`, and one file, `LESSONS_ADK_HARNESS.md`. Reading contents: the folder has a master index with status APPROVED and three briefs, each carrying problem, evidence, intent, invariants, and preservation — an APPROVED CORRECTION PACKAGE, CP-01 through CP-03, all fields present. The file's contents are two retrospective-FLAGGED entries, each naming a target doc, a placement, and exact wording — a DOCTRINE JOURNAL by its contents, not just its name; entries become IN-2026-09-21-01 and -02. CP-02 renames a gate across the Factory; that alone fails the fast path. Provisional route: LARGE. One question I cannot answer from disk: IN-…-02 cites `TRM_PLAYBOOK.md`, which the Hub does not have — GAP-…-01; does a doc ride in, or does it land flagged? Awaiting your APPROVED on scope and classification.
> **Operator:** Lands flagged. Approved.
> **Agent:** Recorded. Snapshotting the two cargo units into the run folder's `INTAKE_SNAPSHOT/` as received — that copy is what Sol and Cody will read. Phase 2. For CP-02 the search terms are the old gate name, the new gate name, and "pre-deployment gate"; scope is the five tiers plus MANIFEST and CHANGELOG. Fourteen hits: nine CHANGE across four docs, three CONSISTENT, two HISTORY. Placements verified — the FFM_PLAYBOOK checklist calls it "Stage 7 Completion Checklist," not "phase-close checklist" as the brief says; anchoring there and flagging it. Proposed wording per row… IN-…-01's sentence lands verbatim; the one-line lead-in I added before it is marked ENGINEER-PROPOSED — approve or strike it. CP-03 is already true at SOFTWARE_FACTORY_PLAYBOOK §2.5 item 5 — proposing NO-CHANGE with the quote; your approval makes it so. Route with the finished map: five touch-list docs, a Factory-wide rename — LARGE, no downgrade proposed. Awaiting your APPROVED on the UPDATE MAP.
> **Operator:** Approved, including the NO-CHANGE.
> **Agent:** Recorded. Phase 3 is Sol's — launch him with the QA Lead line; I wait for Gate 3.
> *(later)* **Agent:** Gate 3 passed. Working tree: the map, the snapshot and today's session file are dirty — exactly the §N expected run-state set, nothing else — so I commit the run-state checkpoint, and the tree is clean. Branch created from the approved BASE_SHA `4c3b2a1`. Lightest first: FEAT_PLAYBOOK — archived as `_ARCHIVE/FEAT_PLAYBOOK_v1_0.md`; `git hash-object` on the archive and `git rev-parse 4c3b2a1:03_BUILD_METHODOLOGY/FEAT_PLAYBOOK.md` print the same blob SHA, and so does the staged copy; edited per §C rows 1–2, header 1.0 → 1.1, lints clean, committed. … Last content commit done; CONTENT_SHA recorded in the handoff — the map stays as it was frozen. Handoff committed. Nothing pushed. Gate 4 evidence: five docs, five archives with matching blob SHAs, MANIFEST rows for the five equal their headers, stated count untouched at 29 (DRIFT-…-01, parked), CHANGELOG five rows, lints zero new, baseline nine unchanged. Awaiting your APPROVED to publish the branch.
> **Operator:** Approved.
> **Agent:** Approval time recorded in the handoff and committed as the Gate 4 record. Pushed. Remote tip reported. Your move: launch Cody with the QA line — the branch carries everything he needs, including the intake snapshot. I stop here.

## Anti-Patterns (skill-specific)

1. **Asking Tony "small or large?"** The route comes from evidence (`decision-trees/route-selection.md`); you ask only the smallest question evidence cannot settle.
2. **Drafting wording in Phase 4, or hiding it in the map.** All wording is proposed in the map and approved at Gate 2; Phase 4 applies it exactly. Any word you add to intake-supplied wording is marked ENGINEER-PROPOSED in its §C row (D15).
3. **Adjudicating a correction.** NO-CHANGE is a proposal with evidence; CONFLICT is BLOCKED; Tony rules (D17).
4. **Propagating from memory.** Header-declared dependents are the start; the search and its per-hit dispositions are the proof (D19).
5. **Pushing before Gate 4** — for any reason. The compare URL comes after the push, which comes after approval (D18).
6. **Repairing outside the map.** A file not on the touch list is a Gate 2 amendment, not a repair.
7. **Bumping a version twice in one run.** Repairs amend the row and cite `QA-F<nn>` in the commit (D22).
8. **Guessing the archive version** or skipping the fidelity diff (AP-6).
9. **"While I'm in here" fixes** — baseline lint reds, typos in untouched docs, an index count that was already stale at BASE, tempting refactors → CONCERNS, `DRIFT-…` rows, or follow-up findings. Never the diff.
10. **Asking the Operator to run git.** He creates the PR and merges. That is all.
11. **Obeying cargo conventions over Hub law** (D15) — content lands verbatim, mechanics translate, translations get flagged.
12. **Skipping narration to go faster.** Speed the Operator cannot hear is opacity.
13. **Branching from main by habit.** The approved BASE_SHA is the execution base; main is only the base when the map says so (D18).
14. **Escalating mechanics as conflict.** A placement anchor or a row format is a mechanical clarification — evidence first, then the smallest question; CONFLICT is for incompatible governing requirements (D17).
15. **Classifying by filename.** "LESSONS" in a name proves nothing; contents, status, intent, and authority decide the class (D16).
16. **Writing into the frozen map.** After the Gate 2 line, the map changes only by approved amendment; CONTENT_SHA and the Gate 4 record belong in the handoff / RUN_SUMMARY (D18, AP-19).
17. **Proving fidelity with `diff` on a CRLF checkout.** Compare blob SHAs (`git hash-object`, `git rev-parse :<archive>`), never working-tree bytes (AP-21).
18. **Refusing a lawful resume because the tree is dirty — or resuming on a dirty tree without classifying it.** Compare the dirty set to map §N; exact subset → checkpoint commit → clean → execute; anything else → STOP (D15a, D22, AP-22).
19. **Leaving the intake behind.** If `INTAKE_SNAPSHOT/` is not on the pushed branch, Cody has no intake; that is a BLOCKED precondition of your own making (AP-20).

## When You're Done

All phases for your route complete; PR merged by the Operator; sweep clean; `_INBOX/` empty; intake stamped with IDs and the PR number; durable folder complete; parked XB items restated; run summary delivered aloud. Then say what would improve this skill — every run before v1.0 is a test of the skill itself.

## Version History

| Version | Date | Change |
|---------|------|--------|
| 0.8-DRAFT | 2026-09-26 | Final bounded hardening after TEST B / C1 / C2 (no redesign). P0: resume reconstructs run, BASE_SHA, route, gate status, phase, expected-vs-actual dirty set and next legal action from git + durable artifacts + disk; RECOVERY.md / session advisory. P1.7: `INTAKE_SNAPSHOT/` copied as received on Gate 1 approval, immutable, committed no later than the handoff commit. P2: §N carries the row-derived tally, the expected run-state set and the full commit plan; Gate 2 line is the freeze — CONTENT_SHA never written into the map. P4.1: dirty set classified against §N (subset → run-state checkpoint commit → clean tree → execute; else STOP). P4.2.5: archive fidelity by Git-object method (`git hash-object` / `git rev-parse :<archive>` vs `git rev-parse <BASE_SHA>:<path>`); `git show | diff -` retired. P4.5: CONTENT_SHA recorded in handoff / RUN_SUMMARY. P5: explicit CONTENT_SHA → handoff commit → Gate 4 → `gate 4 approval record` metadata commit → push → Cody records QA_START_SHA. P6.1 / P9.3 / P9.5 / P9.7: snapshot on the branch, stamps in RUN_SUMMARY, durable set updated, recovery files advisory. Worked example and anti-patterns 16–19 added. IMPLEMENTED — VALIDATED / FINAL HARDENING CANDIDATE. |
| 0.7-DRAFT | 2026-09-14 | TEST A hardening (bounded). P0/P1: proposed BASE_SHA from discovery; content-first classification (filename supporting only); baseline drift parked as `DRIFT-…`; CONFLICT vs mechanical CLARIFICATION presented separately. P2: map is a run-state / planning write; BASE_SHA recorded in §0 before Gate 2 (no longer "pending until branch creation"); ENGINEER-PROPOSED wording marked in §C; §K typed CONFLICT / CLARIFICATION; §G updates only run-caused derived fields, drift parked. P4: branch from the approved BASE_SHA or reuse the run branch at BASE / a lawful descendant — the `git checkout main && git pull` branch step removed; drift values left as at BASE. P5/P8/P9: `<run-branch>` and `<merge-target>` replace hard-coded names. Worked example and anti-patterns 2, 9, 13–15 updated. IMPLEMENTED — AWAITING INDEPENDENT VALIDATION. |
| 0.6-DRAFT | 2026-09-14 | **Became the Engineer child of the family** (methodology moved from the former root SKILL.md, which is superseded). Phase 1 rebuilt on the eleven-class taxonomy with stable IDs and a provisional evidence-driven route; Phase 2 rebuilt as propagation analysis into the single UPDATE MAP (search terms, per-hit dispositions, proposed wording, NO-CHANGE proposals, CONFLICT → BLOCKED, route evidence §P); the former Phase 3 route stop folded into the map (exception ceremony only without a clone); Phase 3 now the acceptance-contract wait (LARGE); Phase 4 loses the push and gains the per-doc checklist (lint-before-commit, archive fidelity, single-line header, Version History ordering, derived-field recompute, CONTENT_SHA); Phase 5 handoff + Gate 4 as the only push boundary; Phase 6 bounded QA repair with REPAIR_CONTENT_SHA; Phase 9 sweep gains ID stamping, deterministic PR-number discovery, durable-vs-debris, no-tag rule. Worked example rewritten for a correction-package run. Anti-patterns 1–7 new. AWAITING INDEPENDENT VALIDATION. |
| 0.3-DRAFT | 2026-08-10 | (as root SKILL.md) Phase 1 cargo scan moved to `_INBOX/` with mandatory D16 triage aloud: PACK / NEW DOC / SUPERSEDING DOC. Resume path added at intake per D15a. Phase 4 dance gains superseding-doc mechanics. Phase 6 sweep requires `_INBOX/` empty at close. |
| 0.2-DRAFT | 2026-08-05 | (as root SKILL.md) Phase 1 rebuilt around cargo scan of promotion packs; Phase 3 flipped to local git PRIMARY; Phase 2 gains placement verification; new-doc mechanics; anti-patterns 7–8 of that version. |
| 0.1-DRAFT | 2026-07-12 | (as root SKILL.md) Initial methodology. Six phases, four stop gates, operator-owned route decision with mid-flight checkpoint. |
